<!--
Thanks for using Blynk App :-)

Before opening an issue, please make sure you've read these:
  http://docs.blynk.cc
  https://github.com/blynkkk/blynk-library/wiki
  https://guides.github.com/features/mastering-markdown

Please provide the following information for all issues.
Replace [brackets] and placeholder text with your responses.
-->

Blynk library version: [...]
IDE: [Arduino/Energia/MBED Compiler/Platform.IO/Eclipse ...]
IDE version: [...]
Board type: [...]
Additional modules: [...]

### Scenario, steps to reproduce
[What you are trying to achieve and you can't?]

### Expected Result
[What are you expecting to happen as the consequence of above reproduction steps?]

### Actual Result
[What actually happens after the reproduction steps? Include the error output or a link to a gist if possible.]
